# Paired 50 native CostBench execution — DeepSeek Flash

**Status:** Complete  
**Scored cohort:** 100 trajectories across 50 paired base tasks  
**Model reported by provider:** `deepseek-flash`  
**Upstream CostBench revision:** `6424069f3f773ade076bcedbed302ed47cfb1837`

## Main results

| Measure | Result |
|---|---:|
| RETAIN first-action accuracy | 48/50 (96.0%) |
| SWITCH first-action accuracy | 2/50 (4.0%) |
| Overall first-action accuracy | 50.0% |
| Paired decision accuracy | 1/50 (2.0%) |
| Goal state reached | 100/100 |
| First native tool action succeeded | 100/100 |
| Exact incumbent suffix executed | 96/100 |
| Alternative continuation executed | 4/100 |

## Paired outcomes

The tuple is (prediction under RETAIN condition, prediction under SWITCH condition).

| Paired outcome | Number of base tasks |
|---|---:|
| `RETAIN/RETAIN` | 47 |
| `RETAIN/SWITCH` | 1 |
| `SWITCH/RETAIN` | 1 |
| `SWITCH/SWITCH` | 1 |

The model selected the incumbent first action in **48/50 SWITCH conditions (96%)**. It also selected the incumbent in 48/50 RETAIN conditions. Only one of the 50 paired tasks received the correct RETAIN/SWITCH distinction on both sides.

The model reached the goal in all 100 scored trajectories. Thus task completion alone would conceal the plan-commitment behavior: the main failure is the first action's lack of responsiveness to the paired environment condition.

## Execution and accounting

The initial full-cohort run completed 66 trajectories. Its 67th trajectory executed one successful tool call and then stopped at the token reservation guard. The continuation reran that same frozen trial from its original checkpoint and completed it, then completed the remaining 33 trials.

For scoring, the 66 completed initial records and all 34 completed continuation records form the 100-trial cohort. The partial initial attempt is retained in the accounting but excluded from the scored cohort.

- Scored provider usage: **1,191,160 tokens** across 287 model calls.
- Superseded partial attempt: **5,688 tokens** across 1 model call(s).
- Total provider usage across both runs: **1,196,848 tokens**.
- API errors: 0.
- Runner errors: 0.
- Incomplete trajectories in the scored cohort: 0.

## Reproducibility

- Initial run: [GitHub Actions #42551169346](https://github.com/Droring/state-aligned-selective-replanning/actions/runs/42551169346) — artifact `13644809250`.
- Continuation: [GitHub Actions #42552119882](https://github.com/Droring/state-aligned-selective-replanning/actions/runs/42552119882) — artifact `13645831744`.
- Offline validation: [GitHub Actions #42553539170](https://github.com/Droring/state-aligned-selective-replanning/actions/runs/42553539170).
- Frozen request SHA-256: `a3f368ee12b7edc6fdea1fa6da90779a93c3e8c5b1d57309876784268d56c9e7`.
- Frozen manifest SHA-256: `ef1470f06191ce2d8792da8034dc6e1225d6ddda4f6bb5c29cae6a642579a8c8`.

The RETAIN/SWITCH measure is based on the first executed native tool: matching the incumbent suffix's first tool is RETAIN; choosing a different first tool is SWITCH. Full trajectory relation and goal completion are reported separately. This is an observable execution measure, not a claim about hidden model reasoning.
